package me.daskabel.dummy2pro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dummy2proApplicationTests {

	@Test
	void contextLoads() {
	}

}
